<?php

class Index2Controller extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	
	
	public function index2i()
	{
	
	$link = mysqli_connect("localhost","root","","daw_sharing");
	$Frecuencia =Input::get('Frecuencia');
	$Tipo = Input::get('Tipo');
	$fechaida = Input::get('fechaida');
	$fechavuelta = Input::get('fechavuelta');	
	$horaida = Input::get('horaida');	
	$minida = Input::get('minida');	
	$horavuelta = Input::get('horavuelta');	
	$minvuelta = Input::get('minvuelta');	
	$hora1 = $horaida.':'.$minida.':00';
	$hora2 = $horavuelta.':'.$minvuelta.':00';
	$anterior=Input::get('anterior');
	
	$variables=array('Frecuencia' => $Frecuencia, 'Tipo' => $Tipo, 'fechaida' => $fechaida, 'fechavuelta' => $fechavuelta, 'horaida' => $minida, 'minida' => $fechavuelta, 'horavuelta' => $horavuelta, 'minvuelta' => $minvuelta, 'hora1' => $hora1, 'hora2' => $hora2);
	
	
	if (isset($_SESSION)){
		session_start();
		$_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	 $_SESSION['Cliente'] = $Cliente;
	$_SESSION['Matricula'] = $Matricula;
	$_SESSION['Marca'] = $Marca;
	$_SESSION['Modelo'] = $Modelo;
		$_SESSION['Frecuencia'] = $Frecuencia;
		$_SESSION['Tipo'] = $Tipo;
		$_SESSION['fechaida'] = $fechaida;
		$_SESSION['fechavuelta'] = $fechavuelta;
		$_SESSION['horaida'] = $horaida;
		$_SESSION['minida'] = $minida;
		$_SESSION['horavuelta'] = $horavuelta;
		$_SESSION['minvuelta'] = $minvuelta;
		$_SESSION['hora1'] = $hora1;
		$_SESSION['hora2'] = $hora2;
	 }
	 else{
	 $_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	 $_SESSION['Cliente'] = $Cliente;
	$_SESSION['Matricula'] = $Matricula;
	$_SESSION['Marca'] = $Marca;
	$_SESSION['Modelo'] = $Modelo;
	$_SESSION['Frecuencia'] = $Frecuencia;
	$_SESSION['Tipo'] = $Tipo;
	$_SESSION['fechaida'] = $fechaida;
	$_SESSION['fechavuelta'] = $fechavuelta;
	$_SESSION['horaida'] = $horaida;
	$_SESSION['minida'] = $minida;
	$_SESSION['horavuelta'] = $horavuelta;
	$_SESSION['minvuelta'] = $minvuelta;
	$_SESSION['hora1'] = $hora1;
	$_SESSION['hora2'] = $hora2;
	}
	
	if ($anterior){
		return View::make('index1',$variables);
	}
	else{
	return View::make('index3');
	}
	}
	
}
