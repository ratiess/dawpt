<?php

class Index3Controller extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/


	public function index3i()
	{
	
	$link = mysqli_connect("localhost","root","","daw_sharing");
	$EquipatgeGran =Input::get('EquipatgeGran');
	$Fumar =Input::get('Fumar');
	$Animales =Input::get('Animales');
	$MenjarBeure =Input::get('MenjarBeure');
	$plazas =Input::get('plazas');
	$eurosplaza =Input::get('eurosplaza');
	$comentarios =Input::get('comentarios');
	$anterior=Input::get('anterior');
	$siguiente=Input::get('siguiente');
	
	if (isset($_SESSION)){
		session_start();
		$_SESSION['Origen'] = $Origen;
		$_SESSION['Destino'] = $Destino;
		$_SESSION['Cliente'] = $Cliente;
		$_SESSION['Matricula'] = $Matricula;
		$_SESSION['Marca'] = $Marca;
		$_SESSION['Modelo'] = $Modelo;
		$_SESSION['Frecuencia'] = $Frecuencia;
		$_SESSION['Tipo'] = $Tipo;
		$_SESSION['fechaida'] = $fechaida;
		$_SESSION['fechavuelta'] = $fechavuelta;
		$_SESSION['horaida'] = $horaida;
		$_SESSION['minida'] = $minida;
		$_SESSION['horavuelta'] = $horavuelta;
		$_SESSION['minvuelta'] = $minvuelta;
		$_SESSION['hora1'] = $hora1;
		$_SESSION['hora2'] = $hora2;
		$_SESSION['EquipatgeGran'] = $EquipatgeGran;
		$_SESSION['Fumar'] = $Fumar;
		$_SESSION['Animales'] = $Animales;
		$_SESSION['MenjarBeure'] = $MenjarBeure;
		$_SESSION['plazas'] = $plazas;
		$_SESSION['eurosplaza'] = $eurosplaza;
		$_SESSION['comentarios'] = $comentarios;

	 }
	 else{
	 $_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	 $_SESSION['Cliente'] = $Cliente;
	$_SESSION['Matricula'] = $Matricula;
	$_SESSION['Marca'] = $Marca;
	$_SESSION['Modelo'] = $Modelo;
	$_SESSION['Frecuencia'] = $Frecuencia;
	$_SESSION['Tipo'] = $Tipo;
	$_SESSION['fechaida'] = $fechaida;
	$_SESSION['fechavuelta'] = $fechavuelta;
	$_SESSION['horaida'] = $horaida;
	$_SESSION['minida'] = $minida;
	$_SESSION['horavuelta'] = $horavuelta;
	$_SESSION['minvuelta'] = $minvuelta;
	$_SESSION['hora1'] = $hora1;
	$_SESSION['hora2'] = $hora2;
	$_SESSION['EquipatgeGran'] = $EquipatgeGran;
		$_SESSION['Fumar'] = $Fumar;
		$_SESSION['Animales'] = $Animales;
		$_SESSION['MenjarBeure'] = $MenjarBeure;
		$_SESSION['plazas'] = $plazas;
		$_SESSION['eurosplaza'] = $eurosplaza;
		$_SESSION['comentarios'] = $comentarios;
	}
	
	if ($anterior){
		return View::make('index2');
	}
	else{
	mysqli_query($link,"INSERT INTO rutas (Poblacion_ini,Poblacion_fin) VALUES ('$Origen','$Destino')");
	mysqli_query($link,"INSERT INTO vehiculos (Matricula,Marca,Modelo) VALUES ('$Matricula','$Marca','$Modelo')");
	mysqli_query($link,"INSERT INTO fechas (FechaIda, FechaVuelta, HoraIda, HoraVuelta) VALUES ('$fechaida','$fechavuelta','$hora1','$hora2')");
	mysqli_query($link,"INSERT INTO tipos (Tipo) VALUES ('$Tipo')");
	mysqli_query($link,"INSERT INTO realizas (TipoFrecuencia) VALUES ('$Frecuencia')");
	mysqli_query($link,"INSERT INTO viajes (EquipatgeGran,Fumar,Animales,MenjarBeure,NumPlaces,Preu,Comentari) VALUES ('$EquipatgeGran','$Fumar','$Animales','$MenjarBeure','$plazas','$eurosplaza','$comentarios')");
	mysqli_query($link,"INSERT INTO clientesviajes (TipoCliente) VALUES ('$Cliente')");	
	return View::make('misviajes');
	}
	}

}
