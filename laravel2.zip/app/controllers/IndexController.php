<?php

class IndexController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	
	
	
	public function indexi()
	{
	$link = mysqli_connect("localhost","root","","daw_sharing");
	$Origen =Input::get('Origen');
	$Destino = Input::get('Destino');
	
	$variables=array('Origen' => $Origen, 'Destino' => $Destino);
	
	if (isset($_SESSION)){
	$_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	}
	else{
	session_start();
	$_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	}

	return View::make('index1',$variables);
	}

}
