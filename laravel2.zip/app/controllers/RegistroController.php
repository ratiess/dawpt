<?php

class RegistroController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function registrarse()
	{
	
$link = mysqli_connect("localhost","root","","daw_sharing");
$dni =Input::get('DNI');
$nombre = Input::get('Nombre');
$grupescolar =Input::get('GrupEscolar');
$email =Input::get('Email');
$tipocliente =Input::get('TipoCliente');
$contraseña =Input::get('Contraseña');


mysqli_query($link,"INSERT INTO clientes (DNI,Nombre,GrupEscolar,Email,TipoCliente,Contrasena) VALUES ('$dni','$nombre','$grupescolar','$email','$tipocliente','$contraseña')");

	return View::make('iniciosesion');
	}
}
