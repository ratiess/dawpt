<?php

class InicioCerrarController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	
	public function iniciarsesion()
	{
	
	$link = mysqli_connect("localhost","root","","daw_sharing");
	$email =Input::get('Email');
	$password =Input::get('password');

	$var=mysqli_query($link,"SELECT * FROM clientes WHERE Email='$email' and Contrasena='$password'");
	if (mysqli_num_rows($var) > 0){
		if($i=mysqli_fetch_array($var)){
			$nombre=$i['Nombre'];
			session_start();
			$_SESSION['nombre'] = $nombre;
			return View::make('index');
		}
	}else{
	return View::make('iniciosesion');
	}
	}
	
	public function cerrarsession(){
	session_destroy();
	return View::make('iniciosesion');
	}
}
