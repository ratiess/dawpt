<?php

class Index1Controller extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	
	public function index1i()
	{
	
	$link = mysqli_connect("localhost","root","","daw_sharing");
	$Cliente =Input::get('Cliente');
	$Matricula = Input::get('Matricula');
	$Marca = Input::get('Marca');
	$Modelo = Input::get('Modelo');
	$Origen = Input::get('Origen');
	$Destino = Input::get('Destino');	
	
	if (isset($_SESSION)){
	$_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	$_SESSION['Cliente'] = $Cliente;
	$_SESSION['Matricula'] = $Matricula;
	$_SESSION['Marca'] = $Marca;
	$_SESSION['Modelo'] = $Modelo;
		
	 }
	 else{
	 session_start();
	 $_SESSION['Origen'] = $Origen;
	$_SESSION['Destino'] = $Destino;
	 $_SESSION['Cliente'] = $Cliente;
	$_SESSION['Matricula'] = $Matricula;
	$_SESSION['Marca'] = $Marca;
	$_SESSION['Modelo'] = $Modelo;
	
	}
	

	$variables=array('Cliente' => $Cliente, 'Matricula' => $Matricula, 'Marca' => $Marca, 'Modelo' => $Modelo);

	return View::make('index2',$variables);
	}
	
}
