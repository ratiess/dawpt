<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Daw-Sharing</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/misviajes.css" rel="stylesheet">
<link rel='stylesheet' id='prettyphoto-css'  href="css/prettyPhoto.css" type='text/css' media='all'>
<link href="css/fontello.css" type="text/css" rel="stylesheet">
<!--[if lt IE 7]>
<link href="css/fontello-ie7.css" type="text/css" rel="stylesheet">  
<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Quattrocento:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Patua+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<style type="text/css">
body {
	padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
}
</style>
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
<script src="js/jquery.js"></script>
<script src="js/jquery.scrollTo-1.4.2-min.js"></script>
<script src="js/jquery.localscroll-1.2.7-min.js"></script>
<script charset="utf-8">
$(document).ready(function () {
    $("a[rel^='prettyPhoto']").prettyPhoto();
});
</script>
<script type="text/javascript">
    window.onload = function() {
      document.onmousemove = function(e) {
        var x = -(e.clientX/40);
        var y = -(e.clientY/40);
        this.body.style.backgroundPosition = x + 'px ' + y + 'px';
      };
    };
</script>
</head>
<body>
<div class="navbar-wrapper">
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
        <h1 class="brand"><a href="#top">DAW-SHARING</a></h1>
        <nav class="pull-right nav-collapse collapse">
          <ul id="menu-main" class="nav">
			<li><a title="team" href="#team">Información</a></li>
            <li><a title="services" href="#services">Servicios</a></li>
            <li><a title="contact" href="#contact">Contacto</a></li>
			<?php if(!(empty($_SESSION['nombre']))){ ?>
			<li><a title="cerrarsesion" href="inicio">Cerrar Sesión</a></li>
			 <?php }?>	
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
<div id="top"></div>
<div id="headerwrap">

  <header class="clearfix">
    <h1><span>Daw-Sharing</span> el lugar más sencillo para viajar</h1>
    <div class="container">
      <div class="row">
        <div class="span12">
		<h2>Comparte rutas o busca la que más te convenga para ahorrarte costes</h2>
		<div id="linia"></div>
		<h2 id="subtitulo">Localización d'una ruta, introduciendo la población de origen y la de destino</h2>
		  <div id="datos">
		  <form action="../public/misviajess" method="POST">
				<div id="datostitulo">Datos personales</div>
				<div id="datos1"><p class="datos">Nombre del cliente: </p><input type="text" name="DNI"></div>
				<div id="datostitulo">Viajes</div>		
				<div id="datos2"><p class="datos">Tipo: </p><input type="text" name="Nombre"></div>
				<div id="datos3"><p class="datos">Origen: </p><input type="text" name="GrupEscolar"></div>
				<div id="datos4"><p class="datos">Destino: </p><input type="text" name="Email"></div>
				<div id="datos5"><p class="datos">Fecha y hora: </p><input type="text" name="TipoCliente"></div>					
				<input type="submit" value="Eliminar" name="Eliminar" class="cform-submit">	
			</form>
		  </div>
        </div>
      </div>
      <div id="pie">
      </div>
    </div>
  </header>
</div>
<div class="scrollblock">
  <section id="feature">
    <div class="container">
      <div class="row">
        <div class="span12">
          <article>
            <p>We work to make web a beautiful place.</p>
            <p>We craft beautiful designs and convert them into</p>
            <p>fully functional and user-friendy web app.</p>
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
<hr>
<section id="team" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-group-circled"></i></div>
    <h1>Conoce al equipo</h1>
	<h3>Daw Sharing es una empresa dedicada a mejorar la vida de aquellas personas que quieren realizar sus trayectos de forma sencilla y ahorrandose costes.</h3>
    <div class="row">
      <div class="span2 offset1">
        <div class="teamalign"> <img class="team-thumb img-circle" src="img/portrait-1.jpg" alt=""> </div>
        <h3>Javier Ortega</h3>
        <div class="job-position">web designer/developer</div>
      </div>
      <div class="span2">
        <div class="teamalign"> <img class="team-thumb img-circle" src="img/portrait-2.jpg" alt=""> </div>
        <h3>Albert Quesada</h3>
        <div class="job-position">web developer/designer</div>
      </div>
     
    </div>
    <div class="row">
      <div class="span10 offset1">
        <hr class="featurette-divider">
        <div class="featurette">
          <h2 class="featurette-heading">Conoce más sobre nosotros</h2>
          <p>En Daw-Sharing...</p>
        </div>
        <hr class="featurette-divider">
      </div>
    </div>
  </div>
  <div id="go-top"><a class="smoothscroll" title="Back to Top" href="#home"><i class="icon-up-open"></i></a></div>
</section>
<hr>
<section id="services" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-cog-circled"></i></div>
    <h1>SERVICIOS</h1>
    <div class="row">
      <div class="span3">
        <div class="align"> <i class="icon-desktop sev_icon"></i></div>
        <h2>Viaja fácil</h2>
        <p>Encuentra tu trayecto con tan sólo un click.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-vector sev_icon"></i></div>
        <h2>Ahorra Costes</h2>
        <p>Con Daw-Sharing ahorrarás costes de transporte. </p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-basket sev_icon"></i></div>
        <h2>Conoce Gente</h2>
        <p>Además de viajar podrás hacer nuevas amistades y qeu el viaje te sea más ameno.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-mobile-1 sev_icon"></i></div>
        <h2>Contacta</h2>
        <p>Para más información contacta con nosotros en el siguiente <a  href="#contact">link</a>.</p>
      </div>
    </div>
  </div>
</section>
<hr>
<section id="testimonials" class="single-page hidden-phone">
  <div class="container">
    <div class="row">
      <div class="blockquote-wrapper">
        <blockquote class="mega">
          <div class="span4">
            <p class="cite">En pruebas</p>
          </div>
          <div class="span8">
            <p class="alignright">"En pruebas"</p>
          </div>
        </blockquote>
      </div>
    </div>
  </div>
</section>
<hr>
<!--<section id="news" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-pencil-circled"></i></div>
    <h1>Our Blog</h1>
    <div class="row">
      <article class="span4 post"> <img class="img-news" src="img/blog_img-01.jpg" alt="">
        <div class="inside">
          <p class="post-date"><i class="icon-calendar"></i> March 17, 2013</p>
          <h2>A girl running on a road</h2>
          <div class="entry-content">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. &hellip;</p>
            <a href="#" class="more-link">read more</a> </div>
        </div>
      </article>
      <article class="span4 post"> <img class="img-news" src="img/blog_img-02.jpg" alt="">
        <div class="inside">
          <p class="post-date">February 28, 2013</p>
          <h2>A bear sleeping on a tree</h2>
          <div class="entry-content">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. &hellip;</p>
            <a href="#" class="more-link">read more</a> </div>
        </div>
      </article>
      <article class="span4 post"> <img class="img-news" src="img/blog_img-03.jpg" alt="">
        <div class="inside">
          <p class="post-date">February 06, 2013</p>
          <h2>A Panda playing with his baby</h2>
          <div class="entry-content">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. &hellip;</p>
            <a href="#" class="more-link">read more</a> </div>
        </div>
      </article>
    </div>
    <a href="#" class="btn btn-large">Go to our blog</a> </div>
</section>-->
<hr>

<section id="contact" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-mail-2"></i></div>
    <h1>Contacta con nosotros</h1>
    <div class="row">
      <div class="span12">
        <div class="cform" id="theme-form">
          <form action="#" method="post" class="cform-form">
            <div class="row">
              <div class="span6"> <span class="your-name">
                <input type="text" name="your-name" placeholder="Nombre" class="cform-text" size="40" title="your name">
                </span> </div>
              <div class="span6"> <span class="your-email">
                <input type="text" name="your-email" placeholder="Email" class="cform-text" size="40" title="your email">
                </span> </div>
            </div>
            <div class="row">
              <div class="span12"> <span class="message">
                <textarea name="message" class="cform-textarea" cols="40" rows="10" title="drop us a line."></textarea>
                </span> </div>
            </div>
            <div>
              <input type="submit" value="Send message" class="cform-submit pull-left">
            </div>
            <div class="cform-response-output"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<hr>
<div class="footer-wrapper">
  <div class="container">
    <footer> <small>&copy; 2013 Inbetwin Network. All rights reserved. | Template By: <a href="http://www.dzyngiri.com">Dzyngiri</a></small> </footer>
  </div>
</div>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/site.js"></script>
</body>
</html>