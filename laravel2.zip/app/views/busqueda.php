<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Daw-Sharing</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel='stylesheet' id='prettyphoto-css'  href="css/prettyPhoto.css" type='text/css' media='all'>
<link href="css/fontello.css" type="text/css" rel="stylesheet">
<!--[if lt IE 7]>
<link href="css/fontello-ie7.css" type="text/css" rel="stylesheet">  
<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Quattrocento:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Patua+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<style type="text/css">
body {
	padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
}
</style>
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
<script src="js/jquery.js"></script>
<script src="js/jquery.scrollTo-1.4.2-min.js"></script>
<script src="js/jquery.localscroll-1.2.7-min.js"></script>
<script charset="utf-8">
$(document).ready(function () {
    $("a[rel^='prettyPhoto']").prettyPhoto();
});
</script>
<script type="text/javascript">
    window.onload = function() {
      document.onmousemove = function(e) {
        var x = -(e.clientX/40);
        var y = -(e.clientY/40);
        this.body.style.backgroundPosition = x + 'px ' + y + 'px';
      };
    };
</script>
</head>
<body>
<div class="navbar-wrapper">
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
        <h1 class="brand"><a href="#top">DAW-SHARING</a></h1>
        <nav class="pull-right nav-collapse collapse">
          <ul id="menu-main" class="nav">
			<li><a title="team" href="#team">Información</a></li>
            <li><a title="services" href="#services">Servicios</a></li>
            <li><a title="contact" href="#contact">Contacto</a></li>
			<?php if(!(empty($_SESSION['nombre']))){ ?>
			<li><a title="cerrarsesion" href="inicio">Cerrar Sesión</a></li>
			 <?php }?>		 
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
<div id="top"></div>

<?php  
echo $_SESSION['nombre'];
?>
<form action="../public/indexx" method="POST">
<div id="headerwrap">
  <header class="clearfix">
    <h1><span>Daw-Sharing</span> el lugar más sencillo para viajar</h1>
    <div class="container">
      <div class="row">
        <div class="span12">
          <h2>Comparte rutas o busca la que más te convenga para ahorrarte costes</h2>
          <input type="text" name="Origen" placeholder="Origen" class="cform-text" size="40" title="your email">
		  <input type="text" name="Destino" placeholder="Destino" class="cform-text" size="40" title="your email" style="margin-left: 10px;">
          <input type="submit" value="Búsqueda" class="cform-submit" style="margin-left: 10px;">
          <input type="submit" value="Publicar" class="cform-submit" style="margin-left: 10px;">
        </div>
      </div>
      <div class="row">
        <div class="span12">
          <ul class="icon">
            <li><a href="#"><i class="icon-pinterest-circled"></i></a></li>
            <li><a href="#"><i class="icon-facebook-circled"></i></a></li>
            <li><a href="#"><i class="icon-twitter-circled"></i></a></li>
            <li><a href="#"><i class="icon-gplus-circled"></i></a></li>
            <li><a href="#"><i class="icon-skype-circled"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </header>
</div>
</form>
<div class="scrollblock">
  <section id="feature">
    <div class="container">
      <div class="row">
        <div class="span12">
          <article>
            <p>Daw-Sharing la web que estabas buscando para viajar</p>
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
<hr>
<section id="team" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-group-circled"></i></div>
    <h1>Conoce al equipo</h1>
	<h3>Daw Sharing es una empresa dedicada a mejorar la vida de aquellas personas que quieren realizar sus trayectos de forma sencilla y ahorrandose costes.</h3>
    <div class="row">
      <div class="span2 offset1">
        <div class="teamalign"> <img class="team-thumb img-circle" src="img/portrait-1.jpg" alt=""> </div>
        <h3>Javier Ortega</h3>
        <div class="job-position">web designer/developer</div>
      </div>
      <div class="span2">
        <div class="teamalign"> <img class="team-thumb img-circle" src="img/portrait-2.jpg" alt=""> </div>
        <h3>Albert Quesada</h3>
        <div class="job-position">web developer/designer</div>
      </div>
     
    </div>
    <div class="row">
      <div class="span10 offset1">
        <hr class="featurette-divider">
        <div class="featurette">
          <h2 class="featurette-heading">Conoce más sobre nosotros</h2>
          <p>En Daw-Sharing...</p>
        </div>
        <hr class="featurette-divider">
      </div>
    </div>
  </div>
  <div id="go-top"><a class="smoothscroll" title="Back to Top" href="#home"><i class="icon-up-open"></i></a></div>
</section>
<hr>
<section id="services" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-cog-circled"></i></div>
    <h1>SERVICIOS</h1>
    <div class="row">
      <div class="span3">
        <div class="align"> <i class="icon-desktop sev_icon"></i></div>
        <h2>Viaja fácil</h2>
        <p>Encuentra tu trayecto con tan sólo un click.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-vector sev_icon"></i></div>
        <h2>Ahorra Costes</h2>
        <p>Con Daw-Sharing ahorrarás costes de transporte. </p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-basket sev_icon"></i></div>
        <h2>Conoce Gente</h2>
        <p>Además de viajar podrás hacer nuevas amistades y qeu el viaje te sea más ameno.</p>
      </div>
      <div class="span3">
        <div class="align"> <i class="icon-mobile-1 sev_icon"></i></div>
        <h2>Contacta</h2>
        <p>Para más información contacta con nosotros en el siguiente <a  href="#contact">link</a>.</p>
      </div>
    </div>
  </div>
</section>
<hr>
<section id="contact" class="single-page scrollblock">
  <div class="container">
    <div class="align"><i class="icon-mail-2"></i></div>
    <h1>Contacta con nosotros</h1>
    <div class="row">
      <div class="span12">
        <div class="cform" id="theme-form">
          <form action="#" method="post" class="cform-form">
            <div class="row">
              <div class="span6"> <span class="your-name">
                <input type="text" name="your-name" placeholder="Nombre" class="cform-text" size="40" title="your name">
                </span> </div>
              <div class="span6"> <span class="your-email">
                <input type="text" name="your-email" placeholder="Email" class="cform-text" size="40" title="your email">
                </span> </div>
            </div>
            <div class="row">
              <div class="span12"> <span class="message">
                <textarea name="message" class="cform-textarea" cols="40" rows="10" title="drop us a line."></textarea>
                </span> </div>
            </div>
            <div>
              <input type="submit" value="Send message" class="cform-submit pull-left">
            </div>
            <div class="cform-response-output"></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<hr>
<div class="footer-wrapper">
  <div class="container">
    <footer> <small>&copy; 2013 Inbetwin Network. All rights reserved. | Template By: <a href="http://www.dzyngiri.com">Dzyngiri</a></small> </footer>
  </div>
</div>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/site.js"></script>
</body>
</html>