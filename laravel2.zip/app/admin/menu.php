<?php
/*
 * Describe your menu here.
 *
 * There is some simple examples what you can use:
 *
 * 		Admin::menu()->url('/')->label('Start page')->icon('fa-dashboard')->uses('\AdminController@getIndex');
 * 		Admin::menu(User::class)->icon('fa-user');
 * 		Admin::menu()->label('Menu with subitems')->icon('fa-book')->items(function ()
 * 		{
 * 			Admin::menu(\Foo\Bar::class)->icon('fa-sitemap');
 * 			Admin::menu('\Foo\Baz')->label('Overwrite model title');
 * 			Admin::menu()->url('my-page')->label('My custom page')->uses('\MyController@getMyPage');
 * 		});
 */
 
 
Admin::menu()->url('/')->label('Home')->icon('fa-dashboard')->uses('\SleepingOwl\Admin\Controllers\DummyController@getIndex');
Admin::menu('Vehiculo')->icon('fa-dashboard');
Admin::menu('Cliente')->icon('fa-dashboard');
Admin::menu('Ruta')->icon('fa-dashboard');
Admin::menu('Viaje')->icon('fa-dashboard');
Admin::menu('ClientesViaje')->icon('fa-dashboard');
Admin::menu('Fecha')->icon('fa-dashboard');
Admin::menu('Tipo')->icon('fa-dashboard');
Admin::menu('Realiza')->icon('fa-dashboard');



