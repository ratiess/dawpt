<?php

Admin::model('Viaje')->title('Viaje')->columns(function ()
{
	Column::string('vehiculo.Matricula', 'Matricula');
	Column::string('ruta.Poblacion_ini', 'Poblacion_ini');
	Column::string('EquipatgeGranSN', 'Equipatge gran s/n');
	Column::string('FumarSN', 'Fumar s/n');
	Column::string('MenjarBeureSN', 'Menjar/Beure s/n');
	Column::string('Num_Places_Disp', 'Num_Places_Disp');
	Column::string('Preu', 'Preu');
	Column::string('Comentari', 'Comentari');


})->form(function ()
{
	FormItem::select('VEHICULOS_Id', 'Vehiculo')->list('\Vehiculo')->required();
	FormItem::select('RUTA_Id', 'Ruta')->list('\Ruta')->required();
	FormItem::text('EquipatgeGranSN', 'Equipatge gran s/n');
	FormItem::text('FumarSN', 'Fumar s/n');
	FormItem::text('MenjarBeureSN', 'Menjar/Beure s/n');
	FormItem::text('Num_Places_Disp', 'Num_Places_Disp');
	FormItem::text('Preu', 'Preu');
	FormItem::text('Comentari', 'Comentari');
});
