<?php

Admin::model('ClientesViaje')->title('ClientesViajes')->columns(function ()
{
	Column::string('viaje.Preu', 'Preu');
	Column::string('clientes.DNI', 'DNI');

})->form(function ()
{
	FormItem::select('VIAJE_Id', 'Viaje')->list('\Viaje')->required();
	FormItem::select('CLIENTES_Id', 'Cliente')->list('\Cliente')->required();

});
