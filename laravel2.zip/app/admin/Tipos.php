<?php

Admin::model('Tipo')->title('Tipos')->columns(function ()
{
	Column::string('Tipo', 'Tipo');


})->form(function ()
{
	FormItem::text('Tipo', 'Tipo');
});
