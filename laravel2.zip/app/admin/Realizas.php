<?php

Admin::model('Realiza')->title('Realizas')->columns(function ()
{
	Column::string('fecha.Fecha', 'Fecha');
	Column::string('tipo.Tipo', 'Tipo');
	Column::string('ruta.Poblacion_ini', 'Poblacion_ini');
	Column::string('Tipo_Frecuencia', 'Tipo_Frecuencia');

})->form(function ()
{
	FormItem::select('FECHA_Id', 'Fecha')->list('\Fecha')->required();
	FormItem::select('TIPO_Id', 'Tipo')->list('\Tipo')->required();
	FormItem::select('RUTA_Id', 'Ruta')->list('\Ruta')->required();
	FormItem::text('Tipo_Frecuencia', 'Tipo_Frecuencia');
});
