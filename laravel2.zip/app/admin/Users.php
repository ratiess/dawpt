<?php
/*
 * This is a simple example of the main features.
 * For full list see documentation.
 */