<?php

Admin::model('Vehiculo')->title('Vehiculos')->columns(function ()
{
	Column::string('Matricula', 'Matricula');
	Column::string('Marca', 'Marca');
	Column::string('Modelo', 'Modelo');
	Column::string('Tipo_Combustible', 'Tipo_Combustible');
	Column::string('Tipo_Vehiculo', 'Tipo_Vehiculo');

	



})->form(function ()
{
	FormItem::text('Matricula', 'Matricula');
	FormItem::text('Marca', 'Marca');
	FormItem::text('Modelo', 'Modelo');
	FormItem::text('Tipo_Combustible', 'Tipo_Combustible');
	FormItem::text('Tipo_Vehiculo', 'Tipo_Vehiculo');


});
