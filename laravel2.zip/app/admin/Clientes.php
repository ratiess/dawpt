<?php

Admin::model('Cliente')->title('Clientes')->columns(function ()
{
	Column::string('DNI', 'DNI');
	Column::string('Nombre', 'Nombre');
	Column::string('Grup_Escolar', 'Grup_Escolar');
	Column::string('Email', 'Email');
	Column::string('Tipo_Cliente', 'Tipo_Cliente');
	Column::string('vehiculo.Matricula', 'Matricula');
	
	
})->form(function ()
{
	FormItem::text('DNI', 'DNI');
	FormItem::text('Nombre', 'Nombre');
	FormItem::text('Grup_Escolar', 'Grup_Escolar');
	FormItem::text('Email', 'Email');
	FormItem::text('Tipo_Cliente', 'Tipo_Cliente');
	FormItem::select('VEHICULOS_Id', 'Vehiculo')->list('\Vehiculo');

});