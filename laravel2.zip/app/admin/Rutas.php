<?php

Admin::model('Ruta')->title('Rutas')->columns(function ()
{
	Column::string('Poblacion_ini', 'Poblacion_ini');
	Column::string('Poblacion_fin', 'Poblacion_fin');
	Column::string('Distancia', 'Distancia');

})->form(function ()
{
	FormItem::text('Poblacion_ini', 'Poblacion_ini');
	FormItem::text('Poblacion_fin', 'Poblacion_fin');
	FormItem::text('Distancia', 'Distancia');
});
