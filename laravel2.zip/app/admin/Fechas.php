<?php

Admin::model('Fecha')->title('Fechas')->columns(function ()
{
	Column::date('Fecha', 'Fecha');
	Column::string('Hora', 'Hora');

})->form(function ()
{
	FormItem::text('Fecha', 'Fecha');
	FormItem::text('Hora', 'Hora');
});
