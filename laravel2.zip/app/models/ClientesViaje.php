<?php

use SleepingOwl\Models\SleepingOwlModel;

class ClientesViaje extends SleepingOwlModel
{

	protected $fillable = [
		'VIAJE_Id',
		'CLIENTES_Id'
	];
	
	protected $table = "ClientesViajes";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('VIAJE_VEHICULOS_Id', 'id');
	}
	
	
	public function viaje (){
		return $this->belongsTo('Viaje','VIAJE_Id');
	}
	
	public function clientes (){
		return $this->belongsTo('Cliente','CLIENTES_Id');
	}

}