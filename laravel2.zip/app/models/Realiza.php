<?php

use SleepingOwl\Models\SleepingOwlModel;

class Realiza extends SleepingOwlModel
{
	protected $fillable = [
		'FECHA_Id',
		'TIPO_Id',
		'RUTA_Id',
		'Tipo_Frecuencia',

	];
	
	protected $table = "Realizas";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('Id', 'id');
	}

	public function fecha (){
		return $this->belongsTo('Fecha','FECHA_Id');
	}
	
	public function tipo (){
		return $this->belongsTo('Tipo','TIPO_Id');
	}
	
	public function ruta (){
		return $this->belongsTo('Ruta','RUTA_Id');
	}
}