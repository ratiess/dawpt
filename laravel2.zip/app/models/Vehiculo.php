<?php

use SleepingOwl\Models\SleepingOwlModel;

class Vehiculo extends SleepingOwlModel
{

	protected $fillable = [
		'Matricula',
		'Marca',
		'Modelo',
		'Tipo_Combustible',
		'Tipo_Vehiculo'

	];
	
	protected $table = "Vehiculos";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}

	public static function getList()
	{
		return static::lists('Matricula', 'id');
	}
	

}