<?php

use SleepingOwl\Models\SleepingOwlModel;

class Fecha extends SleepingOwlModel
{
	protected $fillable = [
		'Fecha',
		'Hora',
	];
	
	protected $table = "Fechas";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('Fecha', 'id');
	}

}