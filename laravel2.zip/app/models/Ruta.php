<?php

use SleepingOwl\Models\SleepingOwlModel;

class Ruta extends SleepingOwlModel
{
	protected $fillable = [
		'Poblacion_ini',
		'Poblacion_fin',
		'Distancia',
	];
	
	protected $table = "Rutas";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('Poblacion_ini', 'id');
	}

}