<?php

use SleepingOwl\Models\SleepingOwlModel;

class Tipo extends SleepingOwlModel
{
	protected $fillable = [
		'Tipo',

	];
	
	protected $table = "Tipos";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('Tipo', 'id');
	}

}