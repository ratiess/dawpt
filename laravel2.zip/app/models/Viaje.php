<?php

use SleepingOwl\Models\SleepingOwlModel;

class Viaje extends SleepingOwlModel
{
	protected $fillable = [
		'VEHICULOS_Id',
		'RUTA_Id',
		'EquipatgeGranSN',
		'FumarSN',
		'MenjarBeureSN',
		'Num_Places_Disp',
		'Preu',
		'Comentari',
	];
	
	protected $table = "Viajes";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('Preu', 'id');
	}
	
	public function vehiculo (){
		return $this->belongsTo('Vehiculo','VEHICULOS_Id');
	}
	
	public function ruta (){
		return $this->belongsTo('Ruta','RUTA_Id');
	}
	

}