<?php

use SleepingOwl\Models\SleepingOwlModel;

class Cliente extends SleepingOwlModel
{

	protected $fillable = [
		'DNI',
		'Nombre',
		'Grup_Escolar',
		'Email',
		'Tipo_Cliente',
		'VEHICULOS_Id'
	];
	
	protected $table = "Clientes";

	protected $hidden = [
		'created_at',
		'updated_at'
	];

	public function scopeDefaultSort($query)
	{
		return $query->orderBy('id', 'asc');
	}


	public static function getList()
	{
		return static::lists('DNI', 'id');
	}
	
	public function vehiculo (){
		return $this->belongsTo('Vehiculo','VEHICULOS_Id');
	}

}