<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/misviajes', function()
{
	return View::make('misviajes');
});

Route::POST('misviajess','ViajesController@misviajesm');

Route::get('/perfil', function()
{
	return View::make('perfil');
});

Route::POST('perfill','PerfilController@perfilp');

Route::get('/index3', function()
{
	return View::make('index3');
});

Route::POST('index33','Index3Controller@index3i');

Route::get('/index2', function()
{
	return View::make('index2');
});

Route::POST('index22','Index2Controller@index2i');


Route::get('/index1', function()
{
	return View::make('index1');
});

Route::POST('index11','Index1Controller@index1i');

Route::get('/index', function()
{
	return View::make('index');
});

Route::POST('indexx','IndexController@indexi');


Route::get('/inicio', function()
{
	return View::make('iniciosesion');
});

Route::POST('iniciosesionn','InicioCerrarController@iniciarsesion');

Route::get('/registro', function()
{
	return View::make('registro');
});

Route::POST('registroo','RegistroController@registrarse');

